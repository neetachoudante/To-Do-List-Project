<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>To-Do List</h1>
        <div class="input-container">
            <form action="add_task.php" method="POST">
                <input type="text" name="task" id="new-task" placeholder="Task name" required>
                <input type="time" name="time" required>
                <select name="period" required>
                    <option value="AM">AM</option>
                    <option value="PM">PM</option>
                </select>
                <select name="frequency" required>
                    <option value="today">Today</option>
                    <option value="tomorrow">Tomorrow</option>
                    <option value="daily">Daily</option>
                    <option value="monday">Monday</option>
                    <option value="tuesday">Tuesday</option>
                    <option value="wednesday">Wednesday</option>
                    <option value="thursday">Thursday</option>
                    <option value="friday">Friday</option>
                    <option value="saturday">Saturday</option>
                    <option value="sunday">Sunday</option>
                </select>
                <button type="submit">Add</button>
            </form>
        </div>
        <table>
            <thead>
                <tr><th>Task No</th><th>Task</th><th>Time</th><th>Frequency</th><th>Actions</th></tr>
            </thead>
            <tbody id="task-list">
                <?php
                $conn = new mysqli('localhost', 'root', '', 'todo_list');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT * FROM tasks";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $counter = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr data-id='" . $row['id'] . "'>";
                        echo "<td class='task-number'>" . $counter . "</td>";
                        echo "<td class='task-detail'>" . htmlspecialchars($row['task']) . "</td>";
                        echo "<td class='task-time'>" . date("h:i A", strtotime($row['time'])) . "</td>";
                        echo "<td class='task-frequency'>" . htmlspecialchars($row['frequency']) . "</td>";
                        echo "<td class='actions'>";
                        echo "<button class='edit' onclick='editTask(" . $row['id'] . ")'>✏️</button>";
                        echo "<button class='delete' onclick='deleteTask(" . $row['id'] . ")'>🗑️</button>";
                        echo "</td>";
                        echo "</tr>";
                        $counter++;
                    }
                } else {
                    echo "<tr><td colspan='5'>No tasks found.</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
    <script src="script.js"></script>
</body>
</html>
