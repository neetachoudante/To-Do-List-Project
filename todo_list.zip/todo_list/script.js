document.addEventListener("DOMContentLoaded", () => {
    const taskList = document.getElementById("task-list");

    window.editTask = (taskId, taskNumber) => {
        const taskItem = document.querySelector(`tr[data-id='${taskId}']`);
        const taskDetail = taskItem.querySelector(".task-detail").textContent;
        const taskTime = taskItem.querySelector(".task-time").textContent;
        const taskFrequency = taskItem.querySelector(".task-frequency").textContent;
        
        const newTaskDetail = prompt("Edit task", taskDetail);
        const newTaskTime = prompt("Edit time (hh:mm)", taskTime);
        const newTaskFrequency = prompt("Edit frequency", taskFrequency);

        if (newTaskDetail !== null && newTaskTime !== null && newTaskFrequency !== null) {
            const formData = new FormData();
            formData.append('id', taskId);
            formData.append('task', newTaskDetail.trim());
            formData.append('time', newTaskTime.trim());
            formData.append('frequency', newTaskFrequency.trim());

            fetch('edit_task.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data === "Task updated successfully") {
                    taskItem.querySelector(".task-detail").textContent = newTaskDetail.trim();
                    taskItem.querySelector(".task-time").textContent = newTaskTime.trim();
                    taskItem.querySelector(".task-frequency").textContent = newTaskFrequency.trim();
                } else {
                    alert(data);
                }
            });
        }
    };

    window.deleteTask = (taskId, taskNumber) => { 
        if (confirm("Are you sure you want to delete this task?")) {
            const formData = new FormData();
            formData.append('id', taskId);

            fetch('delete_task.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data === "Task deleted successfully") {
                    const taskItem = document.querySelector(`tr[data-id='${taskId}']`);
                    taskItem.remove();
                    
                    const taskItems = document.querySelectorAll('tr[data-id]');
                    taskItems.forEach((item, index) => {
                        const currentTaskId = item.getAttribute('data-id');
                        if (currentTaskId !== taskId) {
                            item.querySelector('.task-number').textContent = index + 1;
                        }
                    });
                } else {
                    alert(data);
                }
            });
        }
    };
});
