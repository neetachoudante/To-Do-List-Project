<?php
session_start();

$id = $_POST['id'];
$task = $_POST['task'];
$time = $_POST['time'];
$frequency = $_POST['frequency'];

$conn = new mysqli('localhost', 'root', '', 'todo_list');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("UPDATE tasks SET task=?, time=?, frequency=? WHERE id=?");
$stmt->bind_param("sssi", $task, $time, $frequency, $id);

if ($stmt->execute() === TRUE) {
    echo "Task updated successfully";
} else {
    echo "Error updating task: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
