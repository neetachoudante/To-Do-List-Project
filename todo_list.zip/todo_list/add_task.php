<?php
session_start();

if(isset($_POST['task']) && isset($_POST['time']) && isset($_POST['frequency'])) {
    $task = $_POST['task'];
    $time = $_POST['time'];
    $frequency = $_POST['frequency'];

    $conn = new mysqli('localhost', 'root', '', 'todo_list');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO tasks (task, time, frequency) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $task, $time, $frequency);

    if ($stmt->execute() === TRUE) {
        $_SESSION['message'] = "Task added successfully!";
    } else {
        $_SESSION['message'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    $_SESSION['message'] = "Error: Some data is missing!";
}

header('Location: index.php');
exit();
?>
