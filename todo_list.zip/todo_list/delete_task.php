<?php
$id = $_POST['id'];

$conn = new mysqli('localhost', 'root', '', 'todo_list');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM tasks";
$result = $conn->query($sql);

$taskNumber = 0; 

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $taskNumber++; 
        if ($row['id'] == $id) {
            break; 
        }
    }
}

$sql = "DELETE FROM tasks WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute() === TRUE) {
    echo "Task " . $taskNumber . " deleted successfully";
} else {
    echo "Error deleting task: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
